Drop your demo input files here:
  meeting_protokoll.pdf
  Projektbriefing.txt
  wissenschaftlicher-Artikel.pdf
  team_kapazitaeten.csv
  whiteboard.png
