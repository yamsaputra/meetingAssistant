/**
 * Audio: stubbed transcription + speech endpoints, ready to wire up.
 *
 * Flip AUDIO_ENABLED to true once your team is ready to demo audio.
 */
import { Router } from 'express';
import multer from 'multer';
import { synthesizeSpeech, transcribeAudio } from '../openaiClient.js';
import { asyncHandler } from '../middleware.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

const AUDIO_ENABLED = false; // flip to true once your models are available

router.post(
  '/transcribe',
  upload.single('file'),
  asyncHandler(async (req, res) => {
    if (!AUDIO_ENABLED) return res.status(501).json({ error: 'Audio not yet enabled in this demo.' });
    if (!req.file) return res.status(400).json({ error: 'file is required' });

    const result = await transcribeAudio({
      buffer: req.file.buffer,
      filename: req.file.originalname,
      mimeType: req.file.mimetype,
    });
    res.json({ text: result.text });
  }),
);

router.post(
  '/speak',
  asyncHandler(async (req, res) => {
    if (!AUDIO_ENABLED) return res.status(501).json({ error: 'Audio not yet enabled in this demo.' });
    const { text } = req.body ?? {};
    if (!text) return res.status(400).json({ error: 'text is required' });

    const audio = await synthesizeSpeech({ text });
    res.json({ audio_base64: audio.toString('base64') });
  }),
);

export default router;
