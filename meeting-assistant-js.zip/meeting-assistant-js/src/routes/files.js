/**
 * File upload, vector-store management, and file_search tool calls.
 */
import { Router } from 'express';
import multer from 'multer';
import { config } from '../config.js';
import {
  addFileToVectorStore,
  createResponse,
  createVectorStore,
  uploadFile,
} from '../openaiClient.js';
import { extractFileSearchCitations, extractText } from '../utils.js';
import { asyncHandler } from '../middleware.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

let cachedVectorStoreId = null;

async function ensureVectorStore(name = 'meeting-assistant-store') {
  if (config.vectorStoreId) return config.vectorStoreId;
  if (cachedVectorStoreId) return cachedVectorStoreId;
  const vs = await createVectorStore(name);
  cachedVectorStoreId = vs.id;
  return vs.id;
}

router.post(
  '/upload',
  upload.single('file'),
  asyncHandler(async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'file is required (multipart field "file")' });

    const uploaded = await uploadFile({
      buffer: req.file.buffer,
      filename: req.file.originalname,
      mimeType: req.file.mimetype,
    });
    const vsId = await ensureVectorStore();
    await addFileToVectorStore(vsId, uploaded.id);

    res.json({
      file_id: uploaded.id,
      filename: req.file.originalname,
      vector_store_id: vsId,
    });
  }),
);

router.get(
  '/vector-store',
  asyncHandler(async (_req, res) => {
    res.json({ vector_store_id: await ensureVectorStore() });
  }),
);

router.post(
  '/search',
  asyncHandler(async (req, res) => {
    const { query, vector_store_id, max_num_results = 5 } = req.body ?? {};
    if (!query) return res.status(400).json({ error: 'query is required' });

    const vsId = vector_store_id || (await ensureVectorStore());

    const response = await createResponse({
      model: config.defaultModel,
      input: query,
      tools: [
        {
          type: 'file_search',
          vector_store_ids: [vsId],
          max_num_results,
        },
      ],
      include: ['file_search_call.results'],
    });

    res.json({
      response_id: response.id,
      answer: extractText(response),
      citations: extractFileSearchCitations(response),
    });
  }),
);

export default router;
