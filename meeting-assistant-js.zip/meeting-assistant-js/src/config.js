/**
 * Central configuration loaded from environment variables.
 */
import 'dotenv/config';

export const config = {
  openaiApiKey: process.env.OPENAI_API_KEY || '',
  defaultModel: process.env.DEFAULT_MODEL || 'gpt-4.1',
  visionModel: process.env.VISION_MODEL || 'gpt-4.1',
  imageModel: process.env.IMAGE_MODEL || 'gpt-image-1',
  vectorStoreId: process.env.VECTOR_STORE_ID || '',
  host: process.env.HOST || '0.0.0.0',
  port: parseInt(process.env.PORT || '8000', 10),
};

if (!config.openaiApiKey) {
  // Defer the throw until something actually tries to use the key, so `node --check`
  // and tooling can import the module safely without an API key set.
  console.warn('[config] OPENAI_API_KEY is not set. Copy .env.example to .env before making requests.');
}
