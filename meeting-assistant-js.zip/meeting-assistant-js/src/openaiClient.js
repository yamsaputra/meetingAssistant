/**
 * Thin wrapper around the OpenAI REST API using node-fetch.
 *
 * No SDK — every call is a plain HTTPS request so the wire format is visible.
 * FormData and Blob are picked up from the Node 18+ globals.
 */
import fetch from 'node-fetch';
import { config } from './config.js';

const BASE_URL = 'https://api.openai.com/v1';

class OpenAIError extends Error {
  constructor(status, body) {
    super(`OpenAI ${status}: ${typeof body === 'string' ? body : JSON.stringify(body)}`);
    this.status = status;
    this.body = body;
  }
}

async function request(path, { method = 'POST', body, headers = {}, raw = false } = {}) {
  if (!config.openaiApiKey) throw new Error('OPENAI_API_KEY is not set.');

  const isForm = typeof FormData !== 'undefined' && body instanceof FormData;
  const init = {
    method,
    headers: {
      Authorization: `Bearer ${config.openaiApiKey}`,
      ...(isForm || body === undefined ? {} : { 'Content-Type': 'application/json' }),
      ...headers,
    },
  };
  if (body !== undefined) init.body = isForm ? body : JSON.stringify(body);

  const res = await fetch(`${BASE_URL}${path}`, init);
  if (!res.ok) {
    let errBody;
    try { errBody = await res.json(); } catch { errBody = await res.text(); }
    throw new OpenAIError(res.status, errBody);
  }
  return raw ? res : res.json();
}

/** POST /v1/responses */
export function createResponse(payload) {
  return request('/responses', { body: payload });
}

/** POST /v1/files (multipart) */
export async function uploadFile({ buffer, filename, mimeType, purpose = 'assistants' }) {
  const form = new FormData();
  form.append('purpose', purpose);
  form.append(
    'file',
    new Blob([buffer], { type: mimeType || 'application/octet-stream' }),
    filename,
  );
  return request('/files', { body: form });
}

/** POST /v1/vector_stores */
export function createVectorStore(name) {
  return request('/vector_stores', { body: { name } });
}

/** POST /v1/vector_stores/{id}/files */
export function addFileToVectorStore(vectorStoreId, fileId) {
  return request(`/vector_stores/${vectorStoreId}/files`, { body: { file_id: fileId } });
}

/** GET /v1/containers/{cid}/files/{fid}/content — returns Buffer */
export async function downloadContainerFile(containerId, fileId) {
  const res = await request(
    `/containers/${containerId}/files/${fileId}/content`,
    { method: 'GET', raw: true },
  );
  return Buffer.from(await res.arrayBuffer());
}

/** POST /v1/audio/transcriptions (kept for the future audio router) */
export async function transcribeAudio({ buffer, filename, mimeType, model = 'gpt-4o-transcribe' }) {
  const form = new FormData();
  form.append('model', model);
  form.append('file', new Blob([buffer], { type: mimeType || 'audio/wav' }), filename);
  return request('/audio/transcriptions', { body: form });
}

/** POST /v1/audio/speech — returns Buffer */
export async function synthesizeSpeech({ text, model = 'gpt-4o-mini-tts', voice = 'alloy' }) {
  const res = await request('/audio/speech', {
    body: { model, voice, input: text },
    raw: true,
  });
  return Buffer.from(await res.arrayBuffer());
}
