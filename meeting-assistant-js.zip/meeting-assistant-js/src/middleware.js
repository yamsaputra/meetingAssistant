/**
 * Wraps an async route handler so that thrown / rejected errors flow into
 * Express's error middleware instead of being silently swallowed.
 */
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

/** Central error middleware -> consistent JSON error shape */
export function errorMiddleware(err, req, res, _next) {
  // eslint-disable-next-line no-console
  console.error('[error]', err);
  const status = err.status && Number.isInteger(err.status) ? err.status : 502;
  res.status(status).json({
    error: err.message || 'Internal error',
    details: err.body ?? undefined,
  });
}
